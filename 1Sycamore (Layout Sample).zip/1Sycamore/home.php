<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Website</title>
    <link rel="stylesheet" href="css/style.css">
    <style>

body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #F5F5F5;
        }
        header {
            background:black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }

        .content {
            padding: 50px;
        }
        footer {
            background:black;
            color: white;
            padding: 0px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

    </style>



</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    

<footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>
    
    <script>
        let currentIndex = 0;
        const images = document.querySelectorAll('.carousel img');
        
        function showNextImage() {
            images[currentIndex].classList.remove('active');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add('active');
        }
        
        setInterval(showNextImage, 3000);
    </script>
</body>
</html>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1 Sycamore Food Ventures</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;3
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #F5F5F5;
        }
        header {
            background:black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }
        .carousel {
            position: relative;
            max-width: 800px;
            margin: 20px auto;
            overflow: hidden;
            border-radius: 10px;
        }
        .carousel img {
            width: 100%;
            display: none;
        }
        .carousel img.active {
            display: block;
        }
        .image-section {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 40px auto;
            max-width: 1000px;
        }
        .image-box {
            width: 23%;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        .image-box img {
            width: 100px;
            height: auto;
            border-radius: 10px;
        }
        .content {
            padding: 50px;
        }
        footer {
            background:black;
            color: white;
            padding: 0px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="http://localhost/1Sycamore/contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    
    <section class="carousel">
        <img src="img/2.jpg" class="active" alt="Slide 1">
   <!--     
        <img src="img/packed.jpg" alt="Slide 2">
        <img src="img/catering.jpg" alt="Slide 3">

-->

    </section>


    

   

    <section class="image-section">
        <div class="image-box">
            <img src="img/eco-friendly.png" alt="BRANDS"  style="position: absolute; left: 130px; top: 780px;" >
           
        </div>
        <div class="image-box">
            <img src="img/menu.png" alt="MENU" style="position: absolute; left: 420px; top: 780px;">
            
        </div>
        <div class="image-box">
            <img src="img/customer-service.png" alt="SERVICES" style="position: absolute; left: 710px; top: 780px;">
            
        </div>
        <div class="image-box">
            <img src="img/order.png" alt="ORDER NOW" style="position: absolute; left: 1000px; top: 780px;">
           
        </div>
    </section>
 
    <!-- WITH U-LINKS -->

    <p style="position: absolute; left: 250px; top: 790px;"><b>BRANDS</b></p>
    <p style="position: absolute; left: 250px; top: 820px;">
    <a href="index.php" style="color: blue; text-decoration: underline;"><i>learn more</i></a></p>


    <p style="position: absolute; left: 530px; top: 790px;"><b>MENU</b></p>
    <p style="position: absolute; left: 530px; top: 820px;">
    <a href="index.php" style="color: blue; text-decoration: underline;"><i>learn more</i></a></p>

    <p style="position: absolute; left: 830px; top: 790px;"><b>SERVICES</b></p>
    <p style="position: absolute; left: 830px; top: 820px;">
    <a href="index.php" style="color: blue; text-decoration: underline;"><i>learn more</i></a></p>


    <p style="position: absolute; left: 1105px; top: 790px;"><b>ORDER NOW</b></p>
    <p style="position: absolute; left: 1105px; top: 820px;">
    <a href="index.php" style="color: blue; text-decoration: underline;"><i>learn more</i></a>
</p>

    

    <p>.</p>
    <p>.</p>
    <p>.</p>
    <p>.</p>


    <?php
include 'dbsycamore.php';
?>


    <footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>
    
    <script>
        let currentIndex = 0;
        const images = document.querySelectorAll('.carousel img');
        
        function showNextImage() {
            images[currentIndex].classList.remove('active');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add('active');
        }
        
        setInterval(showNextImage, 3000);
    </script>
</body>
</html>
