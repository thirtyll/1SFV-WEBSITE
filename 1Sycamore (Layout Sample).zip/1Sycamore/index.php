<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Website</title>
    <link rel="stylesheet" href="css/style.css">
    <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #F5F5F5;
        }
        header {
            background: black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 40px;
            flex-wrap: wrap;
            padding: 50px;
            margin-top: -30px;
        }
        .image-container {
            text-align: center;
            position: relative;
            width: 600px;
            margin-left: -10px;
            height: 470px;
            overflow: hidden;
        }
        .carousel img {
            width: 600px;
            height: auto;
            position: absolute;
            left: 0px;
            top: 0;
            opacity: 0;
            transition: opacity 1s ease-in-out;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
        }
        .carousel img.active {
            opacity: 1;
        }

        /* Animated Text Container */
        .text-container {
            text-align: left;
            margin-left: 20px;
            flex: 1;
            opacity: 0; /* Initially hidden */
            transform: translateX(50px); /* Slide in effect */
            animation: fadeInRight 1.5s ease-in-out forwards; /* Animation */
        }

        /* Animation Keyframes */
        @keyframes fadeInRight {
            0% {
                opacity: 0;
                transform: translateX(50px);
            }
            100% {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .text-container h2 {
            font-size: 30px;
            margin-top: -40px;
            color: orange;
            font-family: 'Georgia', serif;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        .text-container p {
            font-size: 16px;
            color: #666;
            line-height: 1.5;
            text-align: justify;
        }

        /* Animated Button */
        .text-container button {
            background: orange;
            color: white;
            padding: 10px 20px;
            border: none;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: transform 0.3s ease, background 0.3s ease;
        }
        .text-container button:hover {
            background: black;
            transform: scale(1.05);
        }

        footer {
            background: black;
            color: white;
            padding: 0px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>

    <div class="content">
        <!-- Image Carousel -->
        <div class="image-container">
            <div class="carousel">
                <img src="img/2.jpg" alt="Image 1" class="active" style="height: 520px;">
                <img src="img/catering.jpg" alt="Image 2">
                <img src="img/packed.jpg" alt="Image 3">
            </div>
        </div>

        <!-- Description Section -->
        <div class="text-container">
            <h2>Delicious & Quality Food</h2>
            <p>Experience the best catering and packed meal services at 1Sycamore Food Ventures. We ensure every dish meets our high standards of taste and quality. Our meals are carefully prepared using the freshest ingredients, offering a wide variety of dishes to suit every occasion. Whether it's for corporate events, family gatherings, or daily meal plans, we guarantee delicious and nutritious food that satisfies your cravings.</p>
            <button onclick="window.location.href='about.php'">Learn More</button>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>

    <script>
        let currentIndex = 0;
        const images = document.querySelectorAll('.carousel img');
        
        function showNextImage() {
            images[currentIndex].classList.remove('active');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add('active');
        }
        
        setInterval(showNextImage, 3000);
    </script>
</body>
</html>
