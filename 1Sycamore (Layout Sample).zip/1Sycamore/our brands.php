<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Website</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #F5F5F5;
        }
        header {
            background:black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }
        .content {
            padding: 50px;
        }
        .offer-title {
            font-size: 24px;
            font-weight: bold;
            margin: 30px 0;
        }
        .offer-section {
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }
        .offer-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 250px;
            text-align: center;
            transition: transform 0.3s ease-in-out, background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .offer-box:hover {
            transform: scale(1.05);
            background-color: #e5e7e9; /* Light warm tone */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .offer-box h3 {
            margin-bottom: 15px;
        }
        .offer-box img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 10px;
            transition: transform 0.3s ease-in-out;
        }
        .offer-box:hover img {
            transform: scale(1.1);
        }
        .offer-box button {
            background: black;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease-in-out, transform 0.3s ease-in-out;
        }
        .offer-box button:hover {
            background:  #138d75;
            transform: translateY(-3px);
        }
        footer {
            background:black;
            color: white;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="content">
        <div class="offer-title" style="font-family: Comic Sans MS, cursive, sans-serif; font-size: 38px; color:black; margin-top: -20px;">
            1 Sycamore Food Ventures Offers
        </div>

        <div class="offer-section">
            <div class="offer-box">
                <img src="img/manna.png" alt="Manna">
                <h3>Manna</h3>
                <p>Experience pure bliss with our heavenly breads and pastries.</p>
                <button>Learn More</button>
            </div>
            <div class="offer-box">
                <p style="text-color: white;">.</p> 
                <img src="img/elephant.png" alt="Elephant Express">
                <h3 style="margin-top: 25px;">Elephant Express</h3>
                <p style="margin-top: 10px;">Experience a flavor explosion with our authentic Asian cuisine</p>
                <button>Learn More</button>
            </div>
            <div class="offer-box">
                <img src="img/tcr.png" alt="The Coffee Republic" style="height:120px">
                <h3>The Coffee Republic</h3>
                <p>Experience coffee, fresh breads, and with relaxing ambiance</p>
                <button>Learn More</button>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>
</body>
</html>
