<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Website</title>
    <link rel="stylesheet" href="css/style.css">
    <style>

body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #F5F5F5;
        }
        header {
            background:black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }

        .content {
            padding: 50px;
        }
        footer {
            background:black;
            color: white;
            padding: 0px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

    </style>



</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    

<footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>
    
    <script>
        let currentIndex = 0;
        const images = document.querySelectorAll('.carousel img');
        
        function showNextImage() {
            images[currentIndex].classList.remove('active');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add('active');
        }
        
        setInterval(showNextImage, 3000);
    </script>
</body>
</html>
