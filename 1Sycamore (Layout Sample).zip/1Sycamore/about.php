<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #F5F5F5;
        }
        header {
            background: black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }

        /* ABOUT US Section */
        .about-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
        }

        .about-content {
            width: 50%;
            text-align: left;
            margin-top: -60px;
            margin-left: -120px; /* Moves the content slightly to the left */
        }

        .about-content h1 {
            font-family: "Copperplate", "Copperplate Gothic Light", fantasy;
            font-size: 32px;
            margin-bottom: 10px;
        } 
  

        .about-content p {
            font-size: 16px;
            line-height: 1.5;
        }

        .btn-container {
            margin-top: 15px;
        }

        /* Brands Button */
        .brands-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #f39c12; /* Orange for Brands */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
            font-size: 16px;
        }

        .brands-btn:hover {
            background-color: #ffbd33;
        }

        /* Menu Button */
        .menu-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #138d75; /* Green for Menu */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .menu-btn:hover {
            background-color: #73c6b6;
        }

        /* Stay in Touch Section */
        .subscribe-container {
            margin-top: 20px;
        }

        .subscribe-container p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .email-input-container {
            display: flex;
            align-items: center;
            max-width: 400px;
        }

        .email-input {
            flex: 1;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
            outline: none;
            width: 70%;
        }

        .ok-btn {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 0 5px 5px 0;
            font-size: 16px;
            cursor: pointer;
        }

        .ok-btn:hover {
            background-color: gray;
        }

        /* About Us Image */
        .about-image {
            width: 50%;
            text-align: right;
        }

        .about-image img {
            max-width: 100%;
            height: auto;
            border-radius: 10px; /* Optional: for rounded corners */
        }

        footer {
            background: black;
            color: white;
            padding: 0px 0;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="http://localhost/1Sycamore/contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>

    <!-- ABOUT US Section -->
    <section class="about-container">
        <div class="about-content">
            <h1>ABOUT US</h1>
            <p>Select from our different brands with a wide variety of menu featuring Party Trays, Hotbox, and Bento Meals that are freshly prepared and conveniently delivered to your door!</p>
            <div class="btn-container">
                <a href="our brands.php" class="brands-btn">Our Brands</a>
                <a href="our menu.php" class="menu-btn">Our Menu</a>
            </div>

            <!-- Stay in Touch Section -->
            <div class="subscribe-container">
                <p><b>Let's stay in touch!</b></p>
                <div class="email-input-container">
                    <input type="email" class="email-input" placeholder="Enter your email">
                    <button class="ok-btn">OK</button>
                </div>
            </div>
        </div>

        <!-- Image on the Right -->
        <div class="about-image">
            <img src="img/catering.jpg" alt="About Us Image">
        </div>
    </section>

    <footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>

</body>
</html>
