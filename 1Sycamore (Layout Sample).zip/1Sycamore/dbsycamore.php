<?php
$servername = "localhost"; // Change if using a remote server
$username = "root"; // Default for XAMPP, change if needed
$password = ""; // Default for XAMPP (leave empty)
$database = "dbsycamore"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Uncomment to check if connected successfully
// echo "Connected successfully";
?>
