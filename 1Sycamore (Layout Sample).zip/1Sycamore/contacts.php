<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Website</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      text-align: center;
      background-color: #F5F5F5;
    }
    header {
      background: black;
      padding: 8px 0;
    }
    nav ul {
      list-style: none;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 900px;
      margin: 0 auto;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      text-decoration: none;
      color: white;
      font-size: 18px;
    }
    .logo img {
      width: 100px;
      height: auto;
    }
    .contact-title {
      font-size: 32px;
      font-weight: bold;
      margin-top: 80px;  /* Adjusts space from the top */
      margin-bottom: 30px; /* Adjusts space below the title */
    }
    /* Updated Contact Section Layout */
    .contact-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      max-width: 600px;
      margin: auto;
      gap: 20px;
      margin-left: 500px;
      margin-top: 50px;   /* Adds space above the contact section */
      margin-bottom: 100px; /* Adds space below the contact section */
    }
    .contact-item {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 18px;
      text-align: left;
      width: 100%;
    }
    .contact-item img {
      width: 40px;
      height: auto;
      min-width: 40px; /* Prevents image from shrinking too much */
      border-radius: 10px;
    }
    footer {
      background: black;
      color: white;
      padding: 0px 0;  /* Adjusts footer padding */
      position: fixed;
      bottom: 0;
      width: 100%;
    }
    .contact-title {
      font-family: "Copperplate", "Copperplate Gothic Light", fantasy;
      font-size: 50px;
    }
    /* New Subscribe Section for Contact */
    .subscribe-container {
      margin-top: 20px;
    }
    .subscribe-container h1 {
      font-size: 20px;
      margin-left:-170px;
      margin-top:-40px;
    }
    .email-input-container {
      display: flex;
      align-items: center;
      justify-content: center;
      max-width: 350px;
      margin: 0 auto;
    }
    .email-input {
      flex: 1;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px 0 0 5px;
      outline: none;
    }
    .submit-btn {
      padding: 10px 20px;
      background-color: black;
      color: white;
      border: none;
      border-radius: 0 5px 5px 0;
      font-size: 16px;
      cursor: pointer;
    }
    .submit-btn:hover {
      background-color: gray;
    }
  </style>
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us</a></li>
        <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="http://localhost/1Sycamore/contacts.php">Contact Us</a></li>
      </ul>
    </nav>
  </header>

  <?php include 'dbsycamore.php'; ?>

  <!-- Contact Us Section -->
  <h1 class="contact-title">
    <center>Contact Us</center>
  </h1>

  <div class="contact-wrapper">
    <div class="contact-item">
      <img src="img/phone.png" alt="Phone">
      <span>0905 227 0284 or<br>(02) 8852-7328 loc.180 or 181</span>
    </div>
    <div class="contact-item">
      <img src="img/location.png" alt="Location">
      <span>GGB Bldg., Pascor Drive, Brgy. Sto. Niño, <br>Parañaque City, Metro Manila</span>
    </div>
  </div>

  <!-- New Subscribe Section with H1 for "Let's get in touch!" -->
  <div class="subscribe-container">
    <h1>Let's get in touch!</h1>
    <div class="email-input-container">
      <input type="email" class="email-input" placeholder="Enter your email">
      <button class="submit-btn">Submit</button>
    </div>
  </div>

  <footer>
    <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
  </footer>
  
  <script>
    let currentIndex = 0;
    const images = document.querySelectorAll('.carousel img');
    
    function showNextImage() {
      images[currentIndex].classList.remove('active');
      currentIndex = (currentIndex + 1) % images.length;
      images[currentIndex].classList.add('active');
    }
    
    setInterval(showNextImage, 3000);
  </script>
</body>
</html>
