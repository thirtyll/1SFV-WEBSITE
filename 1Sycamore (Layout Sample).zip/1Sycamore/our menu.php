<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #F5F5F5;
        }
        header {
            background: black;
            padding: 8px 0;
        }
        nav ul {
            list-style: none;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: 0 auto;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .logo img {
            width: 100px;
            height: auto;
        }

        /* Product Section */
        .product-section {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 30px;
            gap: 20px; /* Space between products */
            padding: 20px;
        }
        .product-card {
            width: 280px; /* Adjusted width */
            background: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .product-card:hover {
            transform: scale(1.05); /* Slight zoom effect on hover */
            background-color:orange; /* Light warm tone */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .product-card img {
            width: 100%;
            height: 250px; /* Adjusted height */
            border-radius: 10px;
            object-fit: cover; /* Ensures image fills without distortion */
        }
        .product-btn {
            display: inline-block;
            padding: 10px 15px;
            margin-top: 10px;
            background-color:black;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s ease-in-out, transform 0.3s ease-in-out;
        }
        .product-btn:hover {
            background-color:  #138d75;
            transform: translateY(-3px); /* Slight lift effect */
        }

        footer {
            background: black;
            color: white;
            padding: 0px 0;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="logo"><img src="img/Logo 2.png" alt="Logo"></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="http://localhost/1Sycamore/contacts.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>

    <section class="product-section">
        <div class="product-card">
            <img src="img/pastry.png" alt="Pastry">
            <a href="pastry.php" class="product-btn">Pastry & Breads</a>
        </div>
        <div class="product-card">
            <img src="img/packedm.jpg" alt="Packed Meals">
            <a href="packed-meals.php" class="product-btn">Packed Meals</a>
        </div>
        <div class="product-card">
            <img src="img/trays.jpg" alt="Party Platters">
            <a href="party-platters.php" class="product-btn">Party Platters</a>
        </div>
    </section>

    <footer>
        <p>&copy; 2025 1Sycamore Food Ventures Inc. All rights reserved.</p>
    </footer>
</body>
</html>
